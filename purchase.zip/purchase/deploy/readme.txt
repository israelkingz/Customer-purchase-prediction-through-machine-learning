pip install streamlit 
pip install pandas 
pip install pickle
